# Aamshu JARVIS Architecture — v3.1

Aamshu's JARVIS mode is a voice-first assistant interface inspired by fictional AI assistants. It does not grant unrestricted control of the phone.

## Action pipeline

`user voice/text -> intent -> allowlist -> permission/confirmation -> native action -> result`

Supported first actions:
- `phone.call` — opens the phone app with a number; the user confirms the call.
- `sms.compose` — opens the messaging app with recipient/body; the user confirms sending.
- `web.open` — opens a validated HTTPS/HTTP URL.
- `maps.search` — opens Google Maps search for a destination.

Unknown commands remain conversational and cannot execute arbitrary code or shell commands.

## Security boundary

The backend only returns a typed action plan. The mobile app is the final enforcement point and uses an explicit allowlist. The assistant cannot silently place calls, send messages, install software, change security settings, or execute arbitrary device commands.

Future actions should be added one at a time with:
1. explicit capability definition;
2. parameter validation;
3. user confirmation where consequential;
4. Android permission review;
5. audit logging where appropriate;
6. automated tests for abuse and malformed input.

## Wake-word roadmap

A true always-listening wake word requires a native foreground/background audio architecture, battery policy, microphone permission handling, and platform-specific restrictions. v3.1 intentionally uses explicit mic activation rather than pretending to provide an always-on wake word.
