# Aamshu v2 Voice Companion

A fictional adult companion persona with a warm, sweet, calm speaking style.

- Speech-to-text: `@react-native-voice/voice`
- Text-to-speech: Expo Speech
- Default speech locale: `en-IN`
- Microphone permission is requested by Android when voice input is used.
- The companion can give practical advice and switch to assertive boundary-setting mode.
- Assertive mode explicitly avoids threats, revenge, weapons, and violence.

The current backend companion is deterministic. For a richer conversational experience, connect a secured AI model provider on the server rather than embedding provider credentials in the APK.


## Global language selection

The companion now exposes the bundled language catalog. Users can search CLDR-derived language names and native names, select a locale, and pass that locale to speech recognition and text-to-speech. Native Android voice providers may support fewer languages than the catalog; unsupported locales should fall back to device/provider behavior rather than being presented as guaranteed voice support.
