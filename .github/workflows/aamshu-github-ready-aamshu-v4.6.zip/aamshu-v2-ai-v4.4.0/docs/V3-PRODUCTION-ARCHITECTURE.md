# Aamshu v3 Production Architecture

Aamshu v3 moves the companion from a prototype conversation surface toward a release-grade platform boundary.

## Durable conversation state
- User-scoped conversation messages are persisted separately from selective long-term memory.
- Conversation history is bounded per API request and can be cleared independently.
- Long-term memory remains explicit preference/project-context extraction only.

## User data controls
- `GET /api/account/export` returns the authenticated account's exportable application data.
- `DELETE /api/account` permanently deletes the authenticated account and cascades owned data through SQLite foreign keys.
- `GET/DELETE /api/conversations` manages conversation history without touching long-term memory.

## AI architecture
`mobile -> authenticated API -> understanding/policy -> AI provider -> SSE -> mobile`

Provider credentials remain server-side. Streaming remains bounded, rate-limited, timeout-controlled, and disconnect-aware.

## Security boundary
- Account isolation is enforced by `user_id` in persistence queries.
- Authentication sessions are revocable.
- AI requests are rate limited per account.
- Security headers, request IDs, input-size limits, provider endpoint checks, and sandbox isolation remain enabled.
- No offensive attack, retaliation, credential theft, persistence, or autonomous counterattack capability is included.

## Release boundary
Android version is `3.0.0` / versionCode `10`.
An actual APK/AAB still requires a functioning Android/EAS build environment; source validation must not be presented as a successful binary build.
