# Final hardening notes

This package is designed to be honest about what is and is not production-ready.

- No default production account or password is provisioned.
- Production browser CORS requires an explicit `ALLOWED_ORIGINS` list.
- JWT secrets must be at least 32 characters in production.
- Code execution remains disabled unless a dedicated isolated runner is configured.
- The API must not receive a public Docker socket.
- The language catalog is offline and reproducible; it is not a claim that every language has Android STT/TTS support.
- Web dependencies are pinned rather than using `latest`.
- The mobile release metadata is consistent at version 2.1.0 / Android versionCode 3.
