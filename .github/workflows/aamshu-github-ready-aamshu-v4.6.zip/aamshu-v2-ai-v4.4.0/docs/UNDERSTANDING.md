# Aamshu Human-Understanding Layer

Aamshu v2.2 adds a lightweight, deterministic interaction-understanding layer for the companion.

It estimates:
- intent: troubleshooting, building, decisions, explanation, planning, emotional support, casual conversation, or general help
- tone cues: neutral, frustrated, worried, sad, or excited
- urgency: low, medium, or high
- goal: answer, action, reassurance, or listening
- response style: conversational, explanatory, actionable, or warm/concrete
- whether clarification may be needed
- recent conversation context length

These are interaction signals, not medical or psychological diagnoses. The system should describe them as best-effort cues rather than facts about a person.

The companion receives up to eight recent turns. The backend returns the response plus a compact `understanding` object so the mobile client can adapt its presentation without exposing hidden reasoning.

For richer model-based understanding, connect a secured AI provider behind the server. Never put provider API keys in the Android APK.
