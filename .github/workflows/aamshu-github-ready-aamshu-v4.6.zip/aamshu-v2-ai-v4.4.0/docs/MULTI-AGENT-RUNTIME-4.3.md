# Aamshu Multi-Agent Runtime 4.3

Aamshu can now dispatch ready workforce jobs concurrently.

## Modes
- `AI_PROVIDER=none` or missing provider credentials: deterministic mock workers for local development and tests.
- `AI_PROVIDER=openai-compatible` with server-side `AI_API_URL`, `AI_API_KEY`, and `AI_MODEL`: specialist jobs are dispatched to the configured model endpoint.

Credentials are never sent to mobile clients.

## Flow
1. `/api/development/workforce/plan` creates an architect-led dependency graph.
2. `/api/development/workforce/:id/run` executes all currently runnable jobs concurrently.
3. Worker output is structured as summary/findings/proposed_changes/tests/risks.
4. Specialist results unlock the reviewer only after required dependencies complete.
5. Failed jobs are retried up to three attempts by the workforce state machine.
6. Release remains blocked when a job is permanently failed or review gates are unresolved.

## Important boundary
This runtime does not create unlimited hidden model instances. Real parallel AI execution exists only when a configured provider can accept the concurrent requests. Otherwise mock workers preserve deterministic orchestration behavior.
