# Aamshu Streaming Companion

Aamshu v2.6 adds a real incremental response path for OpenAI-compatible providers.

## Flow

`Android XHR -> /api/companion/stream -> SSE -> OpenAI-compatible /chat/completions (stream:true)`

The server keeps provider credentials server-side. The mobile app only receives response events.

### SSE events

- `start`: mode, language, and the understanding result.
- `delta`: one incremental text fragment.
- `done`: provider and completion state.

If the provider is unavailable or not configured, the endpoint streams a deterministic fallback in chunks. This is not model streaming; the event reports `provider: "fallback"`.

## Production requirements

- Use HTTPS for production.
- Configure `AI_PROVIDER=openai-compatible`, `AI_API_URL`, `AI_API_KEY`, and `AI_MODEL` only on the server.
- Ensure the reverse proxy does not buffer SSE responses (`X-Accel-Buffering: no` is sent by Aamshu).
- Apply per-user AI quotas and provider-side rate limits before public launch.
- Monitor upstream timeout/error rates and partial streams.
- Keep the Android app free of provider credentials.

Voice playback intentionally starts after the full streamed response is assembled. Token streaming and audio streaming are separate features and should not be conflated.
