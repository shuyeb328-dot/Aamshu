# Aamshu Global Language Data

## Included

- 1,082 locale records with language/locale IDs, English and native display names, likely script/region, text direction, plural categories, ordinal categories, and locale variants.
- 312 CLDR-derived language profiles for offline language selection.
- 7,910 ISO 639-3 records for broad language identification, including alpha-3 IDs and available alpha-2/bibliographic codes.
- Offline mobile JSON so browsing/searching the catalog does not require the API.
- Authenticated server endpoints: `/api/languages` and `/api/languages/:id`.
- Voice locale selection using BCP-47-style locale IDs when the native Android speech provider supports them.

## Important limitation

“No language data available on the internet” is not a single authoritative dataset. CLDR is the appropriate standards base for locale behavior, while ISO 639-3 is useful for language identifiers. Full dictionaries, corpora, translation models, pronunciation lexicons, and speech models are separate datasets and have different licenses. Aamshu therefore does not copy arbitrary web content or claim that every language has TTS/STT support.

Unicode CLDR 49 is currently a beta/development line. The project records its bundled snapshot and provides `scripts/build-language-data.py` so the catalog can be refreshed from controlled sources.

## Refresh

```bash
python -m pip install Babel==2.18.0 pycountry==24.6.1
python scripts/build-language-data.py
```
