# Aamshu v2 release checklist

- [ ] Set `EXPO_PUBLIC_API_URL` to the real HTTPS API.
- [ ] Create an EAS project and set its project ID.
- [ ] Confirm Android package ownership: `com.aamshu.mobile`.
- [ ] Use EAS-managed signing / Google Play App Signing.
- [ ] Replace privacy-policy contact.
- [ ] Host privacy policy on HTTPS.
- [ ] Complete Data Safety and content rating.
- [ ] Add final screenshots and feature graphic.
- [ ] Replace demo account / development defaults.
- [ ] Deploy API behind HTTPS.
- [ ] Move execution to a dedicated sandbox runner.
- [ ] Add production database, queue, backups, monitoring, and alerting.
