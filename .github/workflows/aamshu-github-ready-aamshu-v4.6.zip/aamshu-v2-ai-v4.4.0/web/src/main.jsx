import React, {useEffect, useState} from "react";
import {createRoot} from "react-dom/client";
import "./styles.css";

const API = import.meta.env.VITE_API_URL || "http://localhost:5000";

async function api(path, options={}) {
  const token = localStorage.getItem("aamshu_token");
  const r = await fetch(API + path, {
    ...options,
    headers: {"Content-Type":"application/json", ...(token ? {Authorization:`Bearer ${token}`} : {}), ...(options.headers||{})}
  });
  const data = await r.json().catch(()=>({}));
  if (!r.ok) throw new Error(data.error || "Request failed");
  return data;
}

function App(){
  const [token,setToken] = useState(localStorage.getItem("aamshu_token"));
  const [email,setEmail] = useState("demo@aamshu.local");
  const [password,setPassword] = useState("");
  const [authMode,setAuthMode] = useState("login");
  const [projects,setProjects] = useState([]);
  const [projectId,setProjectId] = useState("");
  const [prompt,setPrompt] = useState("");
  const [tests,setTests] = useState("");
  const [category,setCategory] = useState("coding");
  const [runs,setRuns] = useState([]);
  const [busy,setBusy] = useState(false);
  const [message,setMessage] = useState("Ready");

  async function login(){
    try {
      if(!email.trim() || password.length < 10) throw new Error("Enter a valid email and a password of at least 10 characters.");
      const path=authMode==="login"?"/api/auth/login":"/api/auth/register";
      const d = await api(path,{method:"POST",body:JSON.stringify({email:email.trim(),password})});
      localStorage.setItem("aamshu_token",d.token); setToken(d.token); setMessage(authMode==="login"?"Signed in":"Account created");
    } catch(e){setMessage(e.message)}
  }
  async function load(){
    if(!token)return;
    try { const p=await api("/api/projects"); setProjects(p); if(!projectId && p[0]) setProjectId(p[0].id); } catch(e){setMessage(e.message)}
  }
  async function run(){
    if(!projectId || !prompt.trim()) return setMessage("Select a project and enter a task");
    setBusy(true);
    try {
      const d=await api("/api/tasks",{method:"POST",body:JSON.stringify({projectId,prompt,tests,category})});
      setRuns(r=>[d.run,...r]); setMessage(d.next==="configure_runner"?"Runner is disabled; configure sandbox for execution.":"Run complete");
    } catch(e){setMessage(e.message)} finally {setBusy(false)}
  }
  useEffect(()=>{load()},[token]);

  if(!token) return <main className="center"><section className="card login"><h1>Aamshu <span>v2</span></h1><p>Autonomous coding console</p><input value={email} onChange={e=>setEmail(e.target.value)} autoComplete="email" placeholder="Email"/><input type="password" value={password} onChange={e=>setPassword(e.target.value)} autoComplete={authMode==="login"?"current-password":"new-password"} placeholder="Password (10+ characters)"/><button onClick={login}>{authMode==="login"?"Sign in":"Create account"}</button><button className="ghost" onClick={()=>setAuthMode(authMode==="login"?"register":"login")}>{authMode==="login"?"Create a new account":"Back to sign in"}</button><small>{message}</small></section></main>;

  return <main>
    <header><div><strong>Aamshu <span>v2</span></strong><small> Autonomous Coding Platform</small></div><button className="ghost" onClick={()=>{localStorage.removeItem("aamshu_token");setToken(null)}}>Sign out</button></header>
    <section className="grid">
      <div className="card">
        <h2>Project</h2>
        <select value={projectId} onChange={e=>setProjectId(e.target.value)}><option value="">Select project</option>{projects.map(p=><option key={p.id} value={p.id}>{p.name}</option>)}</select>
        <h2>Task</h2>
        <div className="chips">{["coding","debugging","refactoring","testing"].map(c=><button key={c} className={category===c?"active":""} onClick={()=>setCategory(c)}>{c}</button>)}</div>
        <textarea value={prompt} onChange={e=>setPrompt(e.target.value)} placeholder="Describe what Aamshu should build or fix..."/>
        <textarea value={tests} onChange={e=>setTests(e.target.value)} placeholder="Optional tests / acceptance criteria..."/>
        <button onClick={run} disabled={busy}>{busy?"Running…":"Run task"}</button>
        <p className="status">{message}</p>
      </div>
      <div className="card">
        <h2>Execution</h2>
        {runs.length===0?<p className="muted">No runs in this session.</p>:runs.map(r=><article className="run" key={r.id}><b>{r.status}</b><small>{r.id}</small><p>{r.diagnostics||"No diagnostics"}</p><small>{r.duration_ms} ms</small></article>)}
      </div>
    </section>
  </main>
}
createRoot(document.getElementById("root")).render(<App/>);
