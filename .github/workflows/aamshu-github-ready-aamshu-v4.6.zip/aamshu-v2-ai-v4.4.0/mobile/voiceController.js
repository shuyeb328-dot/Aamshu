import Voice from "@react-native-voice/voice";
import * as Speech from "expo-speech";

export function createVoiceController({onText,onState,onError}){
 let listening=false;
 Voice.onSpeechResults=e=>{const text=e?.value?.[0]||"";if(text)onText?.(text)};
 Voice.onSpeechStart=()=>{listening=true;onState?.(true)};
 Voice.onSpeechEnd=()=>{listening=false;onState?.(false)};
 Voice.onSpeechError=e=>{listening=false;onState?.(false);onError?.(e?.error?.message||"Voice input failed.")};
 return {
  start:async(locale="en-IN")=>{try{if(!listening)await Voice.start(locale)}catch(e){onError?.(e.message||"Unable to start voice input.")}},
  stop:async()=>{try{await Voice.stop()}catch{}},
  speak:(text,locale="en-IN")=>{Speech.stop();Speech.speak(text,{language:locale,rate:.94,pitch:1.08})},
  stopSpeaking:()=>Speech.stop(),
  destroy:()=>{Speech.stop();Voice.destroy().catch(()=>{});Voice.removeAllListeners()}
 };
}
