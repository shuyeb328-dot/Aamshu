import React, {useEffect, useState} from "react";
import {Alert, KeyboardAvoidingView, Linking, Modal, NativeModules, Platform, Pressable, SafeAreaView, ScrollView, StyleSheet, Text, TextInput, View} from "react-native";
import Constants from "expo-constants";
import {StatusBar} from "expo-status-bar";
import {useURL} from "expo-linking";
import {Ionicons} from "@expo/vector-icons";
import {createVoiceController} from "./voiceController";
import languageData from "./assets/languages.json";

const API = Constants.expoConfig?.extra?.apiBaseUrl || "";
const NativeAssistant = NativeModules?.AamshuAssistant || null;

async function request(path, options={}, token="") {
  const r = await fetch(API + path, {
    ...options,
    headers: {"Content-Type":"application/json", ...(token?{Authorization:`Bearer ${token}`}:{}) , ...(options.headers||{})}
  });
  const data=await r.json().catch(()=>({}));
  if(!r.ok) throw new Error(data.error||"Request failed");
  return data;
}

export default function App(){
  const [token,setToken]=useState("");
  const [email,setEmail]=useState("demo@aamshu.local");
  const [password,setPassword]=useState("");
  const [projects,setProjects]=useState([]);
  const [projectId,setProjectId]=useState("");
  const [prompt,setPrompt]=useState("");
  const [tests,setTests]=useState("");
  const [category,setCategory]=useState("coding");
  const [runs,setRuns]=useState([]);
  const [busy,setBusy]=useState(false);
  const [loginMode,setLoginMode]=useState(true);
  const [settings,setSettings]=useState(false);
  const [companionOpen,setCompanionOpen]=useState(false);
  const [companionMode,setCompanionMode]=useState("companion");
  const [companionInput,setCompanionInput]=useState("");
  const [companionMessages,setCompanionMessages]=useState([]);
  const [understanding,setUnderstanding]=useState(null);
  const [listening,setListening]=useState(false);
  const [selectedLanguage,setSelectedLanguage]=useState("en");
  const [languageSearch,setLanguageSearch]=useState("");
  const [languageOpen,setLanguageOpen]=useState(false);
  const [companionMemories,setCompanionMemories]=useState([]);
  const [memoryLoading,setMemoryLoading]=useState(false);
  const [companionStreaming,setCompanionStreaming]=useState(false);
  const [jarvisOpen,setJarvisOpen]=useState(false);
  const [jarvisInput,setJarvisInput]=useState("");
  const [jarvisResult,setJarvisResult]=useState(null);
  const [jarvisBusy,setJarvisBusy]=useState(false);
  const [historyLoading,setHistoryLoading]=useState(false);
  const [assistantActive,setAssistantActive]=useState(false);
  const voiceRef=React.useRef(null);
  const incomingUrl=useURL();

  useEffect(()=>{
    if(incomingUrl?.includes("action=voice") && token){
      setCompanionOpen(true);
      setTimeout(()=>voiceRef.current?.start(selectedLanguage),250);
    }
  },[incomingUrl,token,selectedLanguage]);

  useEffect(()=>{
    if(!token)return;
    voiceRef.current=createVoiceController({
      onText:text=>setCompanionInput(text),
      onState:setListening,
      onError:message=>Alert.alert("Voice",message)
    });
    return ()=>voiceRef.current?.destroy();
  },[token]);

  function companionStream(value){
    const message=String(value ?? companionInput).trim();
    if(!message || companionStreaming)return;
    setCompanionInput("");
    const history=companionMessages.slice(-8);
    setCompanionMessages(m=>[...m,{role:"human",text:message},{role:"aamshu",text:""}]);
    setCompanionStreaming(true);
    const xhr=new XMLHttpRequest();
    let cursor=0;
    let buffer="";
    let full="";
    let lastLength=0;
    const process=()=>{
      const incoming=xhr.responseText.slice(cursor);
      cursor=xhr.responseText.length;
      buffer += incoming;
      const events=buffer.split(/\n\n/);
      buffer=events.pop()||"";
      for(const event of events){
        const dataLine=event.split(/\r?\n/).find(x=>x.startsWith("data:"));
        const typeLine=event.split(/\r?\n/).find(x=>x.startsWith("event:"));
        if(!dataLine)continue;
        try{
          const data=JSON.parse(dataLine.slice(5).trim());
          const type=typeLine?.slice(6).trim();
          if(type==="start") setUnderstanding(data.understanding||null);
          if(type==="delta" && typeof data.text==="string"){
            full += data.text;
            setCompanionMessages(m=>{ const copy=[...m]; const i=copy.length-1; if(i>=0&&copy[i].role==="aamshu") copy[i]={...copy[i],text:full}; return copy; });
          }
          if(type==="done"){
            if(full && full.length!==lastLength){ lastLength=full.length; voiceRef.current?.speak(full,selectedLanguage); }
            setCompanionStreaming(false);
          }
        }catch{}
      }
    };
    xhr.onreadystatechange=()=>{ if(xhr.readyState>=3) process(); if(xhr.readyState===4){ process(); setCompanionStreaming(false); } };
    xhr.onerror=()=>{setCompanionStreaming(false);Alert.alert("Companion","Streaming connection failed. Check the backend URL and network connection.");};
    xhr.open("POST",API+"/api/companion/stream",true);
    xhr.setRequestHeader("Content-Type","application/json");
    xhr.setRequestHeader("Authorization",`Bearer ${token}`);
    xhr.send(JSON.stringify({message,mode:companionMode,language:selectedLanguage,context:history}));
  }

  async function companionSend(value){
    const message=String(value ?? companionInput).trim();
    if(!message)return;
    companionStream(message);
  }

  async function toggleAssistant(){
    if(!NativeAssistant){ Alert.alert("Android assistant","Native assistant is available after an Android native build."); return; }
    try {
      if(assistantActive){ await NativeAssistant.stopAssistant(); setAssistantActive(false); }
      else { await NativeAssistant.startAssistant(); setAssistantActive(true); }
    } catch(e){ Alert.alert("Assistant", e?.message || "Could not change assistant state."); }
  }

  async function runJarvisCommand(){
    const message=jarvisInput.trim();
    if(!message || jarvisBusy)return;
    try{
      setJarvisBusy(true);
      const d=await request("/api/assistant/command",{method:"POST",body:JSON.stringify({message})},token);
      setJarvisResult(d);
    }catch(e){Alert.alert("Aamshu",e.message)}finally{setJarvisBusy(false)}
  }

  async function executeJarvisAction(){
    const a=jarvisResult;
    if(!a || a.type==="none")return;
    Alert.alert("Confirm device action",a.reply,[
      {text:"Cancel",style:"cancel"},
      {text:"Continue",onPress:async()=>{
        try{
          if(a.type==="phone.call") await Linking.openURL(`tel:${a.target}`);
          else if(a.type==="sms.compose") await Linking.openURL(`sms:${a.target}?body=${encodeURIComponent(a.body||"")}`);
          else if(a.type==="web.open") await Linking.openURL(a.target);
          else if(a.type==="maps.search") await Linking.openURL(`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(a.target||"")}`);
        }catch(e){Alert.alert("Device action",`Could not open the requested app: ${e.message}`)}
      }}
    ]);
  }

  async function auth(){
    try{
      if(!API) throw new Error("Configure EXPO_PUBLIC_API_URL before building.");
      const d=await request(loginMode?"/api/auth/login":"/api/auth/register",{method:"POST",body:JSON.stringify({email,password})});
      setToken(d.token);
    }catch(e){Alert.alert("Authentication",e.message)}
  }
  async function loadConversation(){
    try{ const d=await request("/api/conversations?limit=50",{},token); setCompanionMessages((d.messages||[]).map(x=>({role:x.role,text:x.content}))); }catch(e){}
  }
  async function clearConversation(){
    Alert.alert("Clear conversation","This removes chat history but keeps explicit companion memories.",[
      {text:"Cancel",style:"cancel"},{text:"Clear",style:"destructive",onPress:async()=>{try{setHistoryLoading(true);await request("/api/conversations",{method:"DELETE"},token);setCompanionMessages([]);}catch(e){Alert.alert("Conversation",e.message)}finally{setHistoryLoading(false)}}}
    ]);
  }
  async function exportAccount(){
    try{ const d=await request("/api/account/export",{},token); Alert.alert("Account export","Export prepared. Conversation records: "+((d.conversation||[]).length)); }catch(e){Alert.alert("Export",e.message)}
  }
  async function deleteAccount(){
    Alert.alert("Delete account","This permanently deletes your account, projects, tasks, conversations, and companion memories.",[
      {text:"Cancel",style:"cancel"},{text:"Delete",style:"destructive",onPress:async()=>{try{await request("/api/account",{method:"DELETE"},token);setToken("");setProjects([]);setCompanionMessages([]);setCompanionMemories([]);setSettings(false);}catch(e){Alert.alert("Delete account",e.message)}}}
    ]);
  }
  async function loadCompanionMemories(){
    try{ const d=await request("/api/companion/memories",{},token); setCompanionMemories(d.memories||[]); }catch(e){}
  }
  async function deleteCompanionMemory(id){
    try{ await request(`/api/companion/memories/${encodeURIComponent(id)}`,{method:"DELETE"},token); setCompanionMemories(m=>m.filter(x=>x.id!==id)); }catch(e){Alert.alert("Memory",e.message)}
  }
  async function clearCompanionMemories(){
    Alert.alert("Clear companion memory","This removes saved companion preferences and project context from this account.",[
      {text:"Cancel",style:"cancel"},{text:"Clear",style:"destructive",onPress:async()=>{try{setMemoryLoading(true); await request("/api/companion/memories/",{method:"DELETE"},token); setCompanionMemories([]);}catch(e){Alert.alert("Memory",e.message)}finally{setMemoryLoading(false)}}}
    ]);
  }
  async function loadProjects(){
    try{
      const p=await request("/api/projects",{},token); setProjects(p);
      if(!projectId&&p[0]) setProjectId(p[0].id);
    }catch(e){}
  }
  async function run(){
    if(!projectId||!prompt.trim()) return Alert.alert("Task","Select a project and enter a task.");
    setBusy(true);
    try{
      const d=await request("/api/tasks",{method:"POST",body:JSON.stringify({projectId,prompt,tests,category})},token);
      setRuns(r=>[d.run,...r]);
      Alert.alert("Aamshu",d.next==="configure_runner"?"The secure runner is not enabled on this server yet.":"Task finished.");
    }catch(e){Alert.alert("Run failed",e.message)}finally{setBusy(false)}
  }
  useEffect(()=>{if(token){loadProjects();loadCompanionMemories();loadConversation()}},[token]);

  if(!token) return <SafeAreaView style={s.safe}><StatusBar style="light"/><View style={s.auth}><Text style={s.logo}>Aamshu <Text style={s.green}>v3</Text></Text><Text style={s.sub}>Autonomous coding platform</Text><TextInput style={s.input} value={email} onChangeText={setEmail} autoCapitalize="none" placeholder="Email" placeholderTextColor="#71809e"/><TextInput style={s.input} value={password} onChangeText={setPassword} secureTextEntry placeholder="Password" placeholderTextColor="#71809e"/><Pressable style={s.button} onPress={auth}><Text style={s.buttonText}>{loginMode?"Sign in":"Create account"}</Text></Pressable><Pressable onPress={()=>setLoginMode(v=>!v)}><Text style={s.link}>{loginMode?"Create a new account":"Back to sign in"}</Text></Pressable></View></SafeAreaView>;

  return <SafeAreaView style={s.safe}><StatusBar style="light"/><KeyboardAvoidingView style={{flex:1}} behavior={Platform.OS==="ios"?"padding":undefined}><ScrollView contentContainerStyle={s.page}>
    <View style={s.header}><View><Text style={s.title}>Aamshu <Text style={s.green}>v3</Text></Text><Text style={s.sub}>Autonomous Coding Platform</Text></View><Pressable onPress={()=>setSettings(true)}><Ionicons name="settings-outline" size={25} color="#aab5cf"/></Pressable></View>
    <Pressable style={s.companionButton} onPress={()=>setCompanionOpen(true)}>
      <View><Text style={s.companionTitle}>Aamshu Companion</Text><Text style={s.companionSub}>Talk, ask for advice, or switch to assertive mode</Text></View>
      <Ionicons name="mic" size={24} color="#66e0aa"/>
    </Pressable>
    <Pressable style={s.jarvisButton} onPress={()=>setJarvisOpen(true)}>
      <View><Text style={s.companionTitle}>JARVIS Mode</Text><Text style={s.companionSub}>Ask Aamshu to prepare a safe phone action</Text></View>
      <Ionicons name="flash" size={24} color="#9ca8ff"/>
    </Pressable>
    <View style={s.card}><Text style={s.label}>PROJECT</Text><ScrollView horizontal showsHorizontalScrollIndicator={false} style={{marginBottom:14}}>{projects.map(p=><Pressable key={p.id} style={[s.chip,projectId===p.id&&s.active]} onPress={()=>setProjectId(p.id)}><Text style={s.chipText}>{p.name}</Text></Pressable>)}</ScrollView><Text style={s.label}>TASK TYPE</Text><View style={s.wrap}>{["coding","debugging","refactoring","testing"].map(c=><Pressable key={c} style={[s.chip,category===c&&s.active]} onPress={()=>setCategory(c)}><Text style={s.chipText}>{c}</Text></Pressable>)}</View><TextInput style={[s.input,s.area]} value={prompt} onChangeText={setPrompt} multiline placeholder="Describe what Aamshu should build or fix..." placeholderTextColor="#71809e"/><TextInput style={[s.input,s.areaSmall]} value={tests} onChangeText={setTests} multiline placeholder="Tests / acceptance criteria (optional)" placeholderTextColor="#71809e"/><Pressable style={[s.button,busy&&{opacity:.6}]} disabled={busy} onPress={run}><Text style={s.buttonText}>{busy?"Running…":"Run task"}</Text></Pressable></View>
    <View style={s.card}><Text style={s.label}>EXECUTION</Text>{runs.length===0?<Text style={s.muted}>No runs yet.</Text>:runs.map(r=><View key={r.id} style={s.run}><Text style={s.runStatus}>{r.status}</Text><Text style={s.muted}>{r.diagnostics||"No diagnostics"}</Text><Text style={s.muted}>{r.duration_ms||0} ms</Text></View>)}</View>
  </ScrollView></KeyboardAvoidingView>
  <Modal visible={settings} transparent animationType="slide" onRequestClose={()=>setSettings(false)}><View style={s.modal}><View style={s.modalCard}><Text style={s.title}>Settings</Text><Text style={s.muted}>Backend</Text><Text style={s.muted}>{API||"Not configured"}</Text><Text style={[s.label,{marginTop:18}]}>COMPANION MEMORY</Text><Text style={s.muted}>Aamshu saves only explicit preferences and useful project context.</Text>{companionMemories.length===0?<Text style={s.muted}>No saved companion memories.</Text>:companionMemories.slice(0,8).map(m=><View key={m.id} style={s.memoryRow}><View style={{flex:1}}><Text style={s.memoryKind}>{m.kind.replaceAll("_"," ")}</Text><Text style={s.memoryText}>{m.content}</Text></View><Pressable onPress={()=>deleteCompanionMemory(m.id)}><Ionicons name="trash-outline" size={20} color="#ff8b9d"/></Pressable></View>)}<Pressable style={[s.dangerButton,memoryLoading&&{opacity:.5}]} disabled={memoryLoading} onPress={clearCompanionMemories}><Text style={s.buttonText}>{memoryLoading?"Clearing…":"Clear all companion memory"}</Text></Pressable><Text style={[s.label,{marginTop:18}]}>CONVERSATION DATA</Text><Text style={s.muted}>Chat history is stored separately from long-term memory.</Text><Pressable style={s.secondaryButton} onPress={clearConversation}><Text style={s.buttonText}>{historyLoading?"Clearing…":"Clear conversation history"}</Text></Pressable><Pressable style={s.secondaryButton} onPress={exportAccount}><Text style={s.buttonText}>Export account data</Text></Pressable><Pressable style={s.dangerButton} onPress={deleteAccount}><Text style={s.buttonText}>Delete account and all data</Text></Pressable><Pressable style={s.button} onPress={()=>setSettings(false)}><Text style={s.buttonText}>Close</Text></Pressable></View></View></Modal>
  <Modal visible={companionOpen} transparent animationType="slide" onRequestClose={()=>setCompanionOpen(false)}>
   <View style={s.modal}><View style={s.companionCard}>
    <View style={s.header}><View><Text style={s.title}>Aamshu <Text style={s.green}>Companion</Text></Text><Text style={s.sub}>Warm voice • thoughtful advice • firm boundaries</Text></View><Pressable onPress={()=>{voiceRef.current?.stopSpeaking();setCompanionOpen(false)}}><Ionicons name="close" size={25} color="#aab5cf"/></Pressable></View>
    <View style={s.modeRow}><Pressable style={[s.mode,companionMode==="companion"&&s.modeActive]} onPress={()=>setCompanionMode("companion")}><Text style={s.chipText}>Sweet & calm</Text></Pressable><Pressable style={[s.mode,companionMode==="assertive"&&s.modeActive]} onPress={()=>setCompanionMode("assertive")}><Text style={s.chipText}>Stand up</Text></Pressable></View>
    <Pressable style={s.languagePicker} onPress={()=>setLanguageOpen(true)}><View><Text style={s.label}>VOICE LANGUAGE</Text><Text style={s.languageValue}>{(languageData.languages.find(x=>x.id===selectedLanguage.split("-")[0])||{}).nativeName || selectedLanguage}</Text></View><Ionicons name="chevron-down" size={20} color="#aab5cf"/></Pressable>
    <View style={s.understandingCard}>{understanding?<><Text style={s.understandingTitle}>I'm understanding this as</Text><Text style={s.understandingText}>{understanding.intent.replaceAll("_"," ")} • {understanding.responseStyle.replaceAll("_"," ")}</Text></>:<Text style={s.muted}>I adapt to your goal, tone, and conversation context.</Text>}</View><ScrollView style={s.messages}>{companionMessages.length===0?<Text style={s.muted}>Say hello. Ask for advice, talk through a problem, or ask me to help you think.</Text>:companionMessages.map((m,i)=><View key={i} style={[s.bubble,m.role==="human"?s.humanBubble:s.aamshuBubble]}><Text style={s.bubbleText}>{m.text}</Text></View>)}</ScrollView>
    <View style={s.voiceRow}><TextInput style={[s.input,s.voiceInput]} value={companionInput} onChangeText={setCompanionInput} placeholder={companionStreaming?"Aamshu is replying…":"Talk to Aamshu…"} placeholderTextColor="#71809e"/><Pressable style={[s.micButton,listening&&s.micActive]} onPress={()=>listening?voiceRef.current?.stop():voiceRef.current?.start(selectedLanguage)}><Ionicons name={listening?"stop":"mic"} size={22} color="#fff"/></Pressable><Pressable style={[s.sendButton,companionStreaming&&{opacity:.5}]} disabled={companionStreaming} onPress={()=>companionSend()}><Ionicons name="arrow-up" size={22} color="#fff"/></Pressable></View>
   </View></View>
  </Modal>
  <Modal visible={jarvisOpen} transparent animationType="slide" onRequestClose={()=>setJarvisOpen(false)}>
   <View style={s.modal}><View style={s.modalCard}>
    <View style={s.header}><View><Text style={s.title}>Aamshu <Text style={s.green}>JARVIS</Text></Text><Text style={s.sub}>Intent → permission → action → result</Text></View><Pressable onPress={()=>setJarvisOpen(false)}><Ionicons name="close" size={25} color="#aab5cf"/></Pressable></View>
    <Text style={s.muted}>Try: “call +91…”, “message +91… saying hello”, “navigate to Mysuru Palace”, or paste a website.</Text>
    <TextInput style={[s.input,s.areaSmall]} multiline value={jarvisInput} onChangeText={setJarvisInput} placeholder="What should I prepare?" placeholderTextColor="#71809e"/>
    <Pressable style={s.button} onPress={runJarvisCommand}><Text style={s.buttonText}>{jarvisBusy?"Thinking…":"Analyze command"}</Text></Pressable>
    {jarvisResult&&<View style={s.actionCard}><Text style={s.label}>ACTION PLAN</Text><Text style={s.actionType}>{jarvisResult.type}</Text><Text style={s.muted}>{jarvisResult.reply}</Text>{jarvisResult.type!=="none"&&<Pressable style={s.secondaryButton} onPress={executeJarvisAction}><Text style={s.buttonText}>Confirm & open device action</Text></Pressable>}</View>}
    <Text style={s.securityNote}>Aamshu cannot silently place calls, send messages, or perform unrestricted device actions. You confirm each supported action.</Text>
   </View></View>
  </Modal>
  <Modal visible={languageOpen} transparent animationType="slide" onRequestClose={()=>setLanguageOpen(false)}>
   <View style={s.modal}><View style={s.languageCard}>
    <View style={s.header}><View><Text style={s.title}>Languages</Text><Text style={s.sub}>{languageData.languageCount} language profiles • {languageData.localeCount} locales • {languageData.iso639_3Count} ISO records</Text></View><Pressable onPress={()=>setLanguageOpen(false)}><Ionicons name="close" size={25} color="#aab5cf"/></Pressable></View>
    <TextInput style={s.input} value={languageSearch} onChangeText={setLanguageSearch} placeholder="Search language or native name…" placeholderTextColor="#71809e"/>
    <ScrollView style={s.languageList}>{languageData.languages.filter(x=>{const q=languageSearch.toLowerCase().trim();return !q||`${x.id} ${x.name} ${x.nativeName}`.toLowerCase().includes(q)}).slice(0,200).map(x=><Pressable key={x.id} style={[s.languageItem,selectedLanguage.split("-")[0]===x.id&&s.languageSelected]} onPress={()=>{setSelectedLanguage(x.defaultLocale || x.id);setLanguageOpen(false);setLanguageSearch("")}}><View style={{flex:1}}><Text style={s.languageName}>{x.nativeName}</Text><Text style={s.muted}>{x.name} • {(x.defaultLocale||x.id).toUpperCase()} • {x.direction.toUpperCase()}</Text></View>{selectedLanguage.split("-")[0]===x.id&&<Ionicons name="checkmark" size={20} color="#66e0aa"/>}</Pressable>)}</ScrollView>
   </View></View>
  </Modal>
  </SafeAreaView>
}

const s=StyleSheet.create({
 safe:{flex:1,backgroundColor:"#0b1020"},page:{padding:16,paddingBottom:40},auth:{margin:20,marginTop:120,padding:20,backgroundColor:"#121a2c",borderRadius:20,borderWidth:1,borderColor:"#26304a"},logo:{fontSize:32,fontWeight:"800",color:"#eef2ff"},title:{fontSize:22,fontWeight:"800",color:"#eef2ff"},green:{color:"#51d6a1"},sub:{color:"#8793ad",marginTop:5,marginBottom:18},header:{flexDirection:"row",justifyContent:"space-between",alignItems:"center",marginBottom:18},card:{backgroundColor:"#121a2c",borderWidth:1,borderColor:"#26304a",borderRadius:18,padding:16,marginBottom:14},label:{color:"#8d99b3",fontSize:11,fontWeight:"800",letterSpacing:1,marginBottom:10},input:{backgroundColor:"#0b1020",borderWidth:1,borderColor:"#303b58",borderRadius:12,padding:13,color:"#eef2ff",marginBottom:12},area:{minHeight:125,textAlignVertical:"top"},areaSmall:{minHeight:85,textAlignVertical:"top"},button:{backgroundColor:"#6674ff",borderRadius:12,padding:14,alignItems:"center",marginTop:2},buttonText:{color:"#fff",fontWeight:"800"},link:{color:"#8fa0ff",textAlign:"center",marginTop:16},wrap:{flexDirection:"row",flexWrap:"wrap",marginBottom:10},chip:{backgroundColor:"#1c2740",borderRadius:20,paddingVertical:9,paddingHorizontal:12,marginRight:7,marginBottom:7},active:{backgroundColor:"#6674ff"},chipText:{color:"#eef2ff"},muted:{color:"#8793ad",marginTop:4},run:{borderWidth:1,borderColor:"#2a3653",borderRadius:12,padding:12,marginTop:9},runStatus:{color:"#66e0aa",fontWeight:"800",textTransform:"uppercase"},modal:{flex:1,justifyContent:"flex-end",backgroundColor:"#0008"},modalCard:{backgroundColor:"#121a2c",borderTopLeftRadius:22,borderTopRightRadius:22,padding:20,paddingBottom:35},languageCard:{backgroundColor:"#121a2c",borderTopLeftRadius:22,borderTopRightRadius:22,padding:20,paddingBottom:30,maxHeight:"88%"},languagePicker:{flexDirection:"row",justifyContent:"space-between",alignItems:"center",backgroundColor:"#0b1020",borderWidth:1,borderColor:"#303b58",borderRadius:14,padding:13,marginBottom:12},languageValue:{color:"#eef2ff",fontSize:16,fontWeight:"700"},understandingCard:{backgroundColor:"#0f172a",borderWidth:1,borderColor:"#26304a",borderRadius:12,padding:11,marginBottom:10},understandingTitle:{color:"#8d99b3",fontSize:10,fontWeight:"800",letterSpacing:1,textTransform:"uppercase"},understandingText:{color:"#dce4ff",fontSize:13,fontWeight:"700",marginTop:4},languageList:{marginTop:2},languageItem:{flexDirection:"row",alignItems:"center",padding:13,borderWidth:1,borderColor:"#26304a",borderRadius:12,marginBottom:8},languageSelected:{borderColor:"#66e0aa"},languageName:{color:"#eef2ff",fontSize:16,fontWeight:"700"},memoryRow:{flexDirection:"row",alignItems:"center",backgroundColor:"#0b1020",borderWidth:1,borderColor:"#26304a",borderRadius:12,padding:11,marginTop:8},memoryKind:{color:"#66e0aa",fontSize:10,fontWeight:"800",textTransform:"uppercase"},memoryText:{color:"#eef2ff",fontSize:13,marginTop:3},secondaryButton:{backgroundColor:"#26304a",borderRadius:12,padding:14,alignItems:"center",marginTop:8},dangerButton:{backgroundColor:"#8d3b4b",borderRadius:12,padding:14,alignItems:"center",marginTop:12,marginBottom:8}
});
