const { withAndroidManifest, withMainApplication, withProjectBuildGradle } = require('@expo/config-plugins');
const fs = require('fs');
const path = require('path');

function copyNative(projectRoot) {
  const src = path.join(projectRoot, 'native/android/com/aamshu/assistant');
  const dst = path.join(projectRoot, 'android/app/src/main/java/com/aamshu/assistant');
  fs.mkdirSync(dst, {recursive:true});
  for (const file of fs.readdirSync(src)) fs.copyFileSync(path.join(src,file), path.join(dst,file));
}

module.exports = function withAamshuNative(config) {
  config = withAndroidManifest(config, config => {
    const app = config.modResults.manifest.application?.[0];
    if (app) {
      app.service = app.service || [];
      app.receiver = app.receiver || [];
      if (!app.receiver.some(x => x.$?.['android:name'] === '.assistant.AamshuAssistantReceiver')) {
        app.receiver.push({$:{'android:name':'.assistant.AamshuAssistantReceiver','android:exported':'false'}});
      }
      if (!app.service.some(x => x.$?.['android:name'] === '.assistant.AamshuAssistantService')) {
        app.service.push({$:{'android:name':'.assistant.AamshuAssistantService','android:exported':'false','android:foregroundServiceType':'microphone','android:stopWithTask':'true'}});
      }
    }
    return config;
  });
  config = withProjectBuildGradle(config, config => {
    return config;
  });
  config = withMainApplication(config, config => {
    copyNative(config.modRequest.projectRoot);
    let contents = config.modResults.contents;
    const pkg = 'com.aamshu.assistant.AamshuAssistantPackage';
    if (!contents.includes(pkg)) {
      contents = contents.replace(/^(package .*?;\n|package .*?\n)/m, '$1\nimport com.aamshu.assistant.AamshuAssistantPackage;\n');
      if (contents.includes('PackageList(this).getPackages()')) {
        contents = contents.replace(/(List<ReactPackage> packages = new PackageList\(this\)\.getPackages\(\);)/, '$1\n          packages.add(new AamshuAssistantPackage());');
      } else if (contents.includes('PackageList(this).packages.toMutableList()')) {
        contents = contents.replace(/(val packages = PackageList\(this\)\.packages\.toMutableList\(\))/, '$1\n          packages.add(AamshuAssistantPackage());');
      } else {
        throw new Error('Aamshu native plugin could not locate the React Native PackageList in MainApplication.');
      }
    }
    config.modResults.contents = contents;
    return config;
  });
  return config;
};
