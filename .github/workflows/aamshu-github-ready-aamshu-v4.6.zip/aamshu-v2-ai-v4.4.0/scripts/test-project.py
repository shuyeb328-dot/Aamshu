from pathlib import Path
import json, re, sys
ROOT=Path(__file__).resolve().parents[1]
errors=[]

def load(rel):
    try: return json.loads((ROOT/rel).read_text(encoding="utf-8"))
    except Exception as e: errors.append(f"{rel}: {e}"); return None

mobile=load("mobile/assets/languages.json")
server=load("server/src/data/languages.json")
if mobile != server: errors.append("mobile/server language catalogs differ")
if mobile:
    if mobile.get("languageCount") != len(mobile.get("languages",[])): errors.append("languageCount mismatch")
    if mobile.get("localeCount") != len(mobile.get("locales",[])): errors.append("localeCount mismatch")
    if mobile.get("iso639_3Count") != len(mobile.get("iso639_3",[])): errors.append("iso639_3Count mismatch")
    for key in ("languages","locales","iso639_3"):
        ids=[x.get("id") for x in mobile.get(key,[])]
        if len(ids)!=len(set(ids)): errors.append(f"duplicate IDs in {key}")
for rel in ["mobile/package.json","web/package.json","server/package.json"]:
    if load(rel) is None: pass
app=(ROOT/"mobile/app.config.js").read_text()
for needle in ['version:"2.1.0"','versionCode:3','RECORD_AUDIO','@react-native-voice/voice']:
    if needle not in app: errors.append(f"mobile config missing {needle}")
if 'npm ci' in (ROOT/"docker/Dockerfile.api").read_text(): errors.append("Dockerfile requires absent npm lockfile")
if errors:
    print("FAIL")
    print("\n".join(f"- {e}" for e in errors))
    sys.exit(1)
print("PASS")
print(f"languages={mobile['languageCount']} locales={mobile['localeCount']} iso639_3={mobile['iso639_3Count']}")
