"""Rebuild Aamshu language data from installed Babel + pycountry datasets.

Babel supplies CLDR-derived locale metadata; pycountry supplies ISO 639-3 language records.
Install with: python -m pip install Babel==2.18.0 pycountry==24.6.1
"""
from pathlib import Path
import json
from babel import Locale, localedata
from babel.core import get_global
import pycountry

ROOT=Path(__file__).resolve().parents[1]
ids=[x for x in localedata.locale_identifiers() if x not in ('root','und')]
likely=get_global('likely_subtags')
locales=[]
for ident in ids:
    try:l=Locale.parse(ident)
    except Exception:continue
    maximized=likely.get(ident) or likely.get(l.language)
    parts=maximized.split('_') if maximized else []
    script=next((p for p in parts if len(p)==4),None)
    region=next((p for p in parts if p != l.language and (len(p)==2 or (len(p)==3 and p.isdigit()))),None)
    locales.append({'id':ident.replace('_','-'),'language':l.language,'name':l.get_display_name('en') or ident,'nativeName':l.get_display_name(l.language) or l.get_display_name('en') or ident,'script':l.script or script,'region':l.territory or region,'direction':'rtl' if l.character_order=='right-to-left' else 'ltr','pluralCategories':list(l.plural_form.rules.keys()),'ordinalCategories':list(l.ordinal_form.rules.keys())})
locales.sort(key=lambda x:(x['name'].casefold(),x['id']))
base={}
for r in locales:
    if r['language'] not in base:
        base[r['language']]={**r,'id':r['language'],'defaultLocale':r['id'],'localeCount':0}
    base[r['language']]['localeCount']+=1
    if r['id'] == r['language']:
        base[r['language']]['defaultLocale'] = r['id']
iso=[]
for x in pycountry.languages:
    a3=getattr(x,'alpha_3',None)
    if a3: iso.append({'id':a3,'name':getattr(x,'name',a3),'scope':getattr(x,'scope',None),'type':getattr(x,'type',None),'alpha2':getattr(x,'alpha_2',None),'bibliographic':getattr(x,'bibliographic',None)})
iso.sort(key=lambda x:(x['name'].casefold(),x['id']))
out={'schemaVersion':2,'source':'CLDR-derived Babel locale snapshot + ISO 639-3 pycountry snapshot','localeCount':len(locales),'languageCount':len(base),'iso639_3Count':len(iso),'locales':locales,'languages':sorted(base.values(),key=lambda x:x['name'].casefold()),'iso639_3':iso}
for target in [ROOT/'mobile/assets/languages.json',ROOT/'server/src/data/languages.json']:
    target.write_text(json.dumps(out,ensure_ascii=False,separators=(',',':')),encoding='utf-8')
