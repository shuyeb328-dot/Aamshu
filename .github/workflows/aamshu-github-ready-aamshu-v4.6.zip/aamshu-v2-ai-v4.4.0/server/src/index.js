import "dotenv/config";
import express from "express";
import helmet from "helmet";
import cors from "cors";
import rateLimit from "express-rate-limit";
import { db } from "./store/db.js";
import { authRouter } from "./routes/auth.js";
import { projectsRouter } from "./routes/projects.js";
import { memoryRouter } from "./routes/memory.js";
import { tasksRouter } from "./routes/tasks.js";
import { companionRouter } from "./routes/companion.js";
import { companionStreamRouter } from "./routes/companionStream.js";
import { languagesRouter } from "./routes/languages.js";
import { companionMemoriesRouter } from "./routes/companionMemories.js";
import { conversationsRouter } from "./routes/conversations.js";
import { accountRouter } from "./routes/account.js";
import { assistantRouter } from "./routes/assistant.js";
import { developmentWorkforceRouter } from "./routes/developmentWorkforce.js";
import { aiStatus } from "./services/aiProvider.js";
import { requestId, securityHeaders, securityGate } from "./services/security.js";

const app = express();
const port = Number(process.env.PORT || 5000);
const origins = (process.env.ALLOWED_ORIGINS || "").split(",").map(s=>s.trim()).filter(Boolean);

app.disable("x-powered-by");
app.use(requestId);
securityHeaders(app);
app.use(helmet());
app.use(cors({
  origin(origin, callback) {
    // Non-browser clients may omit Origin. In production, browser origins must
    // be explicitly allow-listed rather than accidentally opening CORS.
    if (!origin) return callback(null, true);
    if (origins.includes(origin)) return callback(null, true);
    if (process.env.NODE_ENV !== "production" && origins.length === 0) return callback(null, true);
    return callback(new Error("origin_not_allowed"));
  }
}));
app.use(express.json({ limit: process.env.BODY_LIMIT || "200kb", strict: true }));
app.use(securityGate);
app.use(rateLimit({ windowMs: 60_000, limit: 120, standardHeaders: "draft-7", legacyHeaders: false }));

app.get("/health", (_,res) => res.json({ok:true,service:"aamshu-v2",version:"3.1.0"}));
app.get("/api/status", (_,res) => res.json({
  service:"aamshu-v2",
  database: !!db,
  sandboxMode: process.env.SANDBOX_MODE || "disabled",
  execution: process.env.SANDBOX_MODE === "docker" ? "enabled" : "disabled",
  ai: aiStatus()
}));

app.use("/api/auth", authRouter);
app.use("/api/projects", projectsRouter);
app.use("/api/memory", memoryRouter);
app.use("/api/tasks", tasksRouter);
app.use("/api/companion", companionRouter);
app.use("/api/companion", companionStreamRouter);
app.use("/api/companion/memories", companionMemoriesRouter);
app.use("/api/conversations", conversationsRouter);
app.use("/api/account", accountRouter);
app.use("/api/assistant", assistantRouter);
app.use("/api/development/workforce", developmentWorkforceRouter);
app.use("/api/languages", languagesRouter);

app.use((err,req,res,next) => {
  console.error(err);
  if (err.message === "origin_not_allowed") return res.status(403).json({error:"origin_not_allowed"});
  if (err.type === "entity.too.large") return res.status(413).json({error:"payload_too_large"});
  if (err instanceof SyntaxError && "body" in err) return res.status(400).json({error:"invalid_json"});
  res.status(500).json({error:"internal_error"});
});

app.listen(port, process.env.HOST || "0.0.0.0", () => {
  console.log(`Aamshu v2 API listening on ${port}`);
});
