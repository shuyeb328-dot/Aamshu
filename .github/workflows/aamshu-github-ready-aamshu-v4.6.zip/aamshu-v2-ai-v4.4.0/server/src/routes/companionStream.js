import {Router} from "express";
import {requireAuth} from "../services/auth.js";
import {understand} from "../services/understanding.js";
import {streamReply} from "../services/aiProvider.js";
import {extractSafeMemory,getCompanionMemories} from "../services/companionMemory.js";
import rateLimit from "express-rate-limit";
import { saveConversationMessage } from "../services/conversations.js";

const FALLBACK="I'm here with you. Tell me what you want to work through, and I'll help you take the next useful step.";
const VIOLENCE=/\b(fight|hit|hurt|attack|revenge|weapon|kill|beat|stab|shoot)\b/i;

function fallbackFor(message, mode, u){
  if(VIOLENCE.test(message)) return "Let's not turn this into violence. I can help you be firm, protect your boundaries, and get to a safer situation.";
  if(mode === "assertive") return "Let's keep this respectful. Be firm about your boundary, but don't escalate the situation.";
  if(u.intent === "troubleshooting") return "Let's make the problem concrete. Send me the error, what you expected, and what happened, and we'll work through it step by step.";
  if(u.intent === "build_or_create") return "Got it. I'll focus on the outcome first, then break the work into the smallest useful steps.";
  if(u.intent === "decision_support") return "Let's compare the options by what matters most to you, then choose the trade-off you can live with.";
  return FALLBACK;
}

function send(res,event,data){ res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`); }
function chunkText(text,size=32){ const out=[]; for(let i=0;i<text.length;i+=size) out.push(text.slice(i,i+size)); return out; }

export const companionStreamRouter=Router();
companionStreamRouter.use(requireAuth);
const streamLimiter=rateLimit({windowMs:60_000,limit:20,standardHeaders:"draft-7",legacyHeaders:false,keyGenerator:req=>req.user?.sub || req.ip});
companionStreamRouter.use(streamLimiter);
companionStreamRouter.post("/stream",async (req,res)=>{
  const message=String(req.body?.message||"").slice(0,5000);
  const mode=req.body?.mode==="assertive"?"assertive":"companion";
  const language=String(req.body?.language||"en").slice(0,35);
  const context=Array.isArray(req.body?.context)?req.body.context.slice(-8):[];
  if(!message.trim()) return res.status(400).json({error:"message_required"});
  extractSafeMemory(req.user.sub,message);
  const memories=getCompanionMemories(req.user.sub);
  const understanding=understand(message,context);
  res.status(200);
  res.setHeader("Content-Type","text/event-stream; charset=utf-8");
  res.setHeader("Cache-Control","no-cache, no-transform");
  res.setHeader("Connection","keep-alive");
  res.setHeader("X-Accel-Buffering","no");
  if(typeof res.flushHeaders === "function") res.flushHeaders();
  send(res,"start",{mode,language,understanding});
  let emitted=0;
  let closed=false;
  req.on("close",()=>{ closed=true; });
  let fullReply="";
  try{
    for await (const delta of streamReply({message,mode,language,understanding,context,memories})){
      if(closed) break;
      if(!delta) continue;
      emitted += delta.length;
      fullReply += delta;
      send(res,"delta",{text:delta.slice(0,12000)});
      if(emitted >= 12000) break;
    }
    if(closed) return;
    if(emitted===0) throw new Error("ai_stream_empty");
    saveConversationMessage(req.user.sub,"human",message,language);
    saveConversationMessage(req.user.sub,"aamshu",fullReply,language);
    send(res,"done",{provider:"ai"});
  }catch(error){
    if(process.env.NODE_ENV !== "production") console.warn("AI stream fallback:",error.message);
    if(emitted===0){
      const fallback=fallbackFor(message,mode,understanding);
      saveConversationMessage(req.user.sub,"human",message,language);
      saveConversationMessage(req.user.sub,"aamshu",fallback,language);
      for(const part of chunkText(fallbackFor(message,mode,understanding))) send(res,"delta",{text:part});
      send(res,"done",{provider:"fallback",fallback:true});
    }else{
      send(res,"done",{provider:"ai",partial:true});
    }
  } finally { res.end(); }
});
