import { Router } from "express";
import { createUser, verifyUser, signSession, requireAuth } from "../services/auth.js";
import { safeAudit } from "../services/security.js";
import rateLimit from "express-rate-limit";

export const authRouter = Router();

const authLimiter = rateLimit({ windowMs: 15 * 60_000, limit: 12, standardHeaders: "draft-7", legacyHeaders: false, message: { error: "too_many_auth_attempts" } });
authRouter.use(authLimiter);

authRouter.post("/register", async (req, res) => {
  try {
    const { email, password } = req.body || {};
    const user = await createUser(String(email || ""), String(password || ""));
    res.status(201).json({ user, token: signSession(user) });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

authRouter.post("/login", async (req, res) => {
  const { email, password } = req.body || {};
  const user = await verifyUser(String(email || ""), String(password || ""));
  if (!user) { safeAudit("auth_failure", { ip: req.ip }); return res.status(401).json({ error: "invalid_credentials" }); }
  safeAudit("auth_success", { userId: user.id });
  res.json({ user, token: signSession(user) });
});


authRouter.post("/logout", requireAuth, async (req, res) => {
  const { db } = await import("../store/db.js");
  db.prepare("UPDATE sessions SET revoked_at = ? WHERE id = ? AND user_id = ?").run(new Date().toISOString(), req.user.jti, req.user.sub);
  res.json({ ok: true });
});


authRouter.post("/logout-all", requireAuth, async (req, res) => {
  const { db } = await import("../store/db.js");
  db.prepare("UPDATE sessions SET revoked_at = ? WHERE user_id = ? AND revoked_at IS NULL").run(new Date().toISOString(), req.user.sub);
  res.json({ ok: true });
});
