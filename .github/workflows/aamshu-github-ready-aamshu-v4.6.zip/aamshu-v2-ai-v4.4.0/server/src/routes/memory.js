import { Router } from "express";
import { nanoid } from "nanoid";
import { db } from "../store/db.js";
import { requireAuth } from "../services/auth.js";

export const memoryRouter = Router();
memoryRouter.use(requireAuth);

function owns(projectId, userId) {
  return db.prepare("SELECT id FROM projects WHERE id=? AND user_id=?").get(projectId,userId);
}

memoryRouter.get("/:projectId", (req,res) => {
  if (!owns(req.params.projectId, req.user.sub)) return res.status(404).json({error:"project_not_found"});
  res.json(db.prepare("SELECT * FROM memories WHERE project_id=? ORDER BY created_at DESC LIMIT 100").all(req.params.projectId));
});

memoryRouter.post("/:projectId", (req,res) => {
  if (!owns(req.params.projectId, req.user.sub)) return res.status(404).json({error:"project_not_found"});
  const content = String(req.body?.content || "").trim();
  const kind = String(req.body?.kind || "lesson").slice(0,40);
  if (!content || content.length > 5000) return res.status(400).json({error:"invalid_memory"});
  const row = {id:nanoid(),project_id:req.params.projectId,kind,content,created_at:new Date().toISOString()};
  db.prepare("INSERT INTO memories (id,project_id,kind,content,created_at) VALUES (@id,@project_id,@kind,@content,@created_at)").run(row);
  res.status(201).json(row);
});
