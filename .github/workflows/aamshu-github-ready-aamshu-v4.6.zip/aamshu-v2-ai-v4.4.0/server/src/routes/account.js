import { Router } from "express";
import { requireAuth } from "../services/auth.js";
import { db } from "../store/db.js";
import { listConversation } from "../services/conversations.js";
import { getCompanionMemories } from "../services/companionMemory.js";
export const accountRouter = Router();
accountRouter.use(requireAuth);
accountRouter.get("/export", (req,res)=>{
  const user=db.prepare("SELECT id,email,created_at FROM users WHERE id=?").get(req.user.sub);
  const projects=db.prepare("SELECT id,name,description,created_at,updated_at FROM projects WHERE user_id=? ORDER BY created_at").all(req.user.sub);
  const tasks=db.prepare("SELECT id,project_id,category,prompt,tests,status,created_at FROM tasks WHERE user_id=? ORDER BY created_at").all(req.user.sub);
  res.json({exportedAt:new Date().toISOString(),user,projects,tasks,companionMemories:getCompanionMemories(req.user.sub),conversation:listConversation(req.user.sub,200)});
});
accountRouter.delete("/", (req,res)=>{
  const tx=db.transaction(()=>db.prepare("DELETE FROM users WHERE id=?").run(req.user.sub));
  tx();
  res.json({ok:true});
});
