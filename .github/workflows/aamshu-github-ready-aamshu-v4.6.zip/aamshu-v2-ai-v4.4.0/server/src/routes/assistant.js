import express from 'express';
import { requireAuth } from '../services/auth.js';
import { planAssistantAction } from '../services/assistantActions.js';

export const assistantRouter = express.Router();
assistantRouter.use(requireAuth);
assistantRouter.post('/command', (req, res) => {
  const message = String(req.body?.message || '').trim();
  if (!message || message.length > 300) return res.status(400).json({ error: 'invalid_message' });
  res.json(planAssistantAction(message));
});
