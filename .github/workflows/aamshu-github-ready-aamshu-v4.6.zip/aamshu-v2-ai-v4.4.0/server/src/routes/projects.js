import { Router } from "express";
import { nanoid } from "nanoid";
import { db } from "../store/db.js";
import { requireAuth } from "../services/auth.js";

export const projectsRouter = Router();
projectsRouter.use(requireAuth);

projectsRouter.get("/", (req,res) => {
  res.json(db.prepare("SELECT * FROM projects WHERE user_id = ? ORDER BY updated_at DESC").all(req.user.sub));
});

projectsRouter.post("/", (req,res) => {
  const name = String(req.body?.name || "").trim();
  if (!name || name.length > 100) return res.status(400).json({error:"invalid_project_name"});
  const now = new Date().toISOString();
  const project = { id:nanoid(), user_id:req.user.sub, name, description:String(req.body?.description||"").slice(0,1000), created_at:now, updated_at:now };
  db.prepare("INSERT INTO projects (id,user_id,name,description,created_at,updated_at) VALUES (@id,@user_id,@name,@description,@created_at,@updated_at)").run(project);
  res.status(201).json(project);
});
