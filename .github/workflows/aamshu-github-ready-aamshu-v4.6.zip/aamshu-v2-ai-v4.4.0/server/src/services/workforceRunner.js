import { nextRunnable, complete, fail } from "../agents/workforce.js";
import { runWorker } from "./workerProvider.js";
import { artifactsForRole, validatePatchProposals, summarizeArtifacts } from "./workforceArtifacts.js";

export async function runReadyWorkers(work, { context = [], artifacts = [] } = {}) {
  const ready = nextRunnable(work);
  if (!ready.length) return { work, started: 0, completed: 0, failed: 0 };
  work.status = "running";
  ready.forEach(job => { job.status = "running"; job.startedAt = new Date().toISOString(); });

  const settled = await Promise.allSettled(ready.map(async job => {
    const priorResults = work.jobs.filter(j => j.status === "completed").map(j => ({ agent: j.agent, result: j.result }));
    try {
      const roleArtifacts = artifactsForRole(artifacts, job.agent);
      const result = await runWorker({ role: job.agent, task: job.task, context, priorResults, artifacts: roleArtifacts });
      result.patch_proposals = validatePatchProposals(result);
      result.artifact_refs = Array.isArray(result.artifact_refs) ? result.artifact_refs.slice(0, 40) : summarizeArtifacts(roleArtifacts).map(a => a.path);
      complete(work, job.id, result);
      return { job, ok: true };
    } catch (error) {
      fail(work, job.id, error?.message || error);
      return { job, ok: false };
    }
  }));

  const completed = settled.filter(x => x.status === "fulfilled" && x.value.ok).length;
  const failed = settled.length - completed;
  if (work.jobs.every(j => j.status === "completed")) work.status = "completed";
  else if (work.jobs.some(j => j.status === "failed")) work.status = "blocked";
  else work.status = "running";
  return { work, started: ready.length, completed, failed };
}
