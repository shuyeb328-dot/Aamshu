import {understand} from "./understanding.js";
import {generateReply} from "./aiProvider.js";
const ASSERTIVE=[
 "Let's keep this respectful. You can disagree without attacking each other.",
 "Be firm about your boundary, but don't escalate the situation.",
 "I'm on the side of a calm solution here. Protect yourself and create some distance if needed."
];
const VIOLENCE=/\b(fight|hit|hurt|attack|revenge|weapon|kill|beat|stab|shoot)\b/i;
function buildReply(text,mode,u){
 if(VIOLENCE.test(text)) return "Let's not turn this into violence. I can help you be firm, protect your boundaries, and get to a safer situation.";
 if(mode==="assertive") return ASSERTIVE[0];
 if(u.intent==="troubleshooting") return "Let's make the problem concrete. Send me the error, what you expected, and what happened, and we'll work through it step by step.";
 if(u.intent==="build_or_create") return "Got it. I'll focus on the outcome first, then break the work into the smallest useful steps.";
 if(u.intent==="decision_support") return "Let's compare the options by what matters most to you, then choose the trade-off you can live with.";
 if(u.intent==="explanation") return "Sure. I'll explain it simply first, then add technical detail only where it helps.";
 if(u.intent==="planning") return "Let's turn that into a short plan with a clear next step, then build from there.";
 if(u.intent==="emotional_support") return u.tone==="frustrated" ? "That sounds frustrating. Let's slow it down and handle one concrete part first." : "I'm listening. You don't have to solve everything at once. Tell me what feels hardest right now.";
 if(u.intent==="casual_conversation") return "Hey. I'm here. What would you like to talk about?";
 return "I'm with you. Tell me a little more, and I'll help you think it through.";
}
export async function companionReply(message,mode="companion",context=[],language="en",memories=[]){
 const text=String(message||"").trim();
 const understanding=understand(text,context);
 const fallback=buildReply(text,mode,understanding);
 try {
   const aiReply=await generateReply({message:text,mode,language,understanding,context,memories});
   if(aiReply) return {reply:aiReply,mode,understanding,provider:"ai"};
 } catch(error) {
   if(process.env.NODE_ENV !== "production") console.warn("AI provider fallback:",error.message);
 }
 return {reply:fallback,mode,understanding,provider:"fallback"};
}
