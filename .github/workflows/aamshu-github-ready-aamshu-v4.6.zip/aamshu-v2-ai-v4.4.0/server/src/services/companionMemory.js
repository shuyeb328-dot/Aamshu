import { nanoid } from "nanoid";
import { db } from "../store/db.js";

const MAX_MEMORIES = 40;
const MAX_CONTENT = 600;

export function getCompanionMemories(userId) {
  if (!userId) return [];
  return db.prepare("SELECT id, kind, content, created_at FROM companion_memories WHERE user_id=? ORDER BY created_at DESC LIMIT ?")
    .all(userId, MAX_MEMORIES);
}

export function rememberCompanionFact(userId, kind, content) {
  const cleanKind=String(kind||"context").slice(0,40);
  const clean=String(content||"").trim().slice(0,MAX_CONTENT);
  if(!userId || !clean) return null;
  const row={id:nanoid(),user_id:userId,kind:cleanKind,content:clean,created_at:new Date().toISOString()};
  db.prepare("INSERT OR IGNORE INTO companion_memories (id,user_id,kind,content,created_at) VALUES (@id,@user_id,@kind,@content,@created_at)")
    .run(row);
  return row;
}

// Store only explicit, useful preferences/context. Do not infer sensitive traits.
export function extractSafeMemory(userId, message) {
  const text=String(message||"").trim();
  const patterns=[
    ["preference", /\b(?:i prefer|i like|i love|i want you to|from now on|please always)\s+(.{3,180})/i],
    ["project_context", /\b(?:my project is|my app is|i'm building|i am building)\s+(.{3,180})/i]
  ];
  for(const [kind,re] of patterns){
    const m=text.match(re);
    if(m?.[1]) return rememberCompanionFact(userId,kind,m[1].replace(/[.?!]+$/,""));
  }
  return null;
}

export function deleteCompanionMemory(userId, id) {
  if (!userId || !id) return false;
  const result = db.prepare("DELETE FROM companion_memories WHERE id=? AND user_id=?").run(id,userId);
  return result.changes > 0;
}

export function clearCompanionMemories(userId) {
  if (!userId) return 0;
  return db.prepare("DELETE FROM companion_memories WHERE user_id=?").run(userId).changes;
}
