const MAX_ARTIFACTS = 40;
const MAX_PATH = 240;
const MAX_CONTENT = 12000;
const MAX_TOTAL = 120000;

function safePath(value) {
  const p = String(value || '').trim().replace(/\\/g, '/');
  if (!p || p.startsWith('/') || p.includes('..') || /\0/.test(p)) return null;
  if (!/^[A-Za-z0-9._\-/]+$/.test(p)) return null;
  return p.slice(0, MAX_PATH);
}

export function normalizeArtifacts(input = []) {
  if (!Array.isArray(input)) return [];
  const out = [];
  let total = 0;
  for (const item of input.slice(0, MAX_ARTIFACTS)) {
    const path = safePath(item?.path);
    if (!path) continue;
    const content = String(item?.content || '').slice(0, MAX_CONTENT);
    if (!content) continue;
    if (total + content.length > MAX_TOTAL) break;
    out.push({ path, content, type: String(item?.type || 'source').slice(0, 40) });
    total += content.length;
  }
  return out;
}

export function summarizeArtifacts(artifacts = []) {
  return normalizeArtifacts(artifacts).map(a => ({ path: a.path, type: a.type, chars: a.content.length }));
}

export function artifactsForRole(artifacts = [], role) {
  const normalized = normalizeArtifacts(artifacts);
  if (!role || role === 'architect' || role === 'reviewer' || role === 'qa' || role === 'security') return normalized;
  const terms = {
    android: /android|\.kt$|\.java$|\.gradle|app\.config|AndroidManifest|native/i,
    backend: /^(server|api|backend)\/|\/(routes|services|store)\/|\.sql$/i,
    ai: /ai|provider|prompt|agent|model|stream/i,
    voice: /voice|speech|audio|stt|tts|microphone/i,
    ui: /mobile|web|ui|screen|component|\.tsx?$|\.jsx?$/i
  };
  const matcher = terms[role];
  if (!matcher) return normalized.slice(0, 8);
  const matched = normalized.filter(a => matcher.test(a.path) || matcher.test(a.content.slice(0, 500)));
  return matched.length ? matched : normalized.slice(0, 8);
}

export function validatePatchProposals(result = {}) {
  const proposals = Array.isArray(result.patch_proposals) ? result.patch_proposals : [];
  return proposals.slice(0, 20).map(p => ({
    operation: ['create','update','delete'].includes(p?.operation) ? p.operation : 'update',
    path: safePath(p?.path) || 'INVALID_PATH',
    content: String(p?.content || '').slice(0, MAX_CONTENT),
    rationale: String(p?.rationale || '').slice(0, 800)
  })).filter(p => p.path !== 'INVALID_PATH');
}
