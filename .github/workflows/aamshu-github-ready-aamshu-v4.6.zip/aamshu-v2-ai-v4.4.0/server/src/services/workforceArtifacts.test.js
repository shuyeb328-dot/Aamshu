import assert from 'node:assert/strict';
import { artifactsForRole, normalizeArtifacts, validatePatchProposals } from './workforceArtifacts.js';

const artifacts = normalizeArtifacts([
  { path: 'mobile/App.js', content: 'const App = () => null;' },
  { path: 'server/src/index.js', content: 'export default {};' },
  { path: '../secret.txt', content: 'blocked' },
  { path: '/etc/passwd', content: 'blocked' }
]);
assert.equal(artifacts.length, 2);
assert.equal(artifactsForRole(artifacts, 'android')[0].path, 'mobile/App.js');
assert.equal(artifactsForRole(artifacts, 'backend')[0].path, 'server/src/index.js');
const proposals = validatePatchProposals({ patch_proposals: [
  { operation: 'update', path: 'mobile/App.js', content: 'x', rationale: 'test' },
  { operation: 'update', path: '../bad', content: 'x' }
]});
assert.equal(proposals.length, 1);
assert.equal(proposals[0].path, 'mobile/App.js');
console.log('workforce artifact tests: PASS');
