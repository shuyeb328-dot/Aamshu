import data from "../data/languages.json" with { type: "json" };

const normalize = (value) => String(value || "").trim().toLowerCase();
const safeInt = (value, fallback, min, max) => {
  const n = Number(value);
  return Number.isInteger(n) ? Math.min(Math.max(n, min), max) : fallback;
};

export function languageCatalog({ q = "", limit = 100, offset = 0 } = {}) {
  const query = normalize(q);
  const source = data.languages;
  const filtered = query
    ? source.filter(x => `${x.id} ${x.name} ${x.nativeName}`.toLowerCase().includes(query))
    : source;
  return {
    schemaVersion: data.schemaVersion,
    source: data.source,
    languageCount: data.languageCount,
    localeCount: data.localeCount,
    iso639_3Count: data.iso639_3Count,
    total: filtered.length,
    offset,
    limit,
    languages: filtered.slice(offset, offset + limit)
  };
}

export function isoCatalog({ q = "", limit = 100, offset = 0 } = {}) {
  const query = normalize(q);
  const filtered = query
    ? data.iso639_3.filter(x => `${x.id} ${x.name} ${x.alpha2 || ""} ${x.bibliographic || ""}`.toLowerCase().includes(query))
    : data.iso639_3;
  return {
    schemaVersion: data.schemaVersion,
    source: data.source,
    total: filtered.length,
    offset,
    limit,
    languages: filtered.slice(offset, offset + limit)
  };
}

export function findLanguage(id) {
  const key = normalize(id).replace(/_/g, "-");
  const base = key.split("-")[0];
  return data.locales.find(x => x.id.toLowerCase() === key)
    || data.languages.find(x => x.id.toLowerCase() === key)
    || data.iso639_3.find(x => x.id.toLowerCase() === key)
    || data.languages.find(x => x.id.toLowerCase() === base)
    || data.locales.find(x => x.language.toLowerCase() === base)
    || null;
}

export { data as languageData };
