import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { sha256, detectConflicts, applyPatchSet, readSnapshot } from './workspaceEngine.js';

test('detects stale base hashes before applying', () => {
  const result = detectConflicts([{ operation:'update', path:'src/a.js', content:'new', base_hash:sha256('old') }], { 'src/a.js': { content:'changed', hash:sha256('changed') } });
  assert.equal(result.clean, false);
  assert.equal(result.conflicts[0].reason, 'base_hash_mismatch');
});

test('applies non-conflicting patch set in isolated root', async () => {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'aamshu-workspace-'));
  await fs.mkdir(path.join(root, 'src'), { recursive:true });
  await fs.writeFile(path.join(root, 'src/a.js'), 'old');
  const snap = await readSnapshot(root, ['src/a.js', 'src/new.js']);
  const result = await applyPatchSet(root, [
    { operation:'update', path:'src/a.js', content:'new', base_hash:snap['src/a.js'].hash },
    { operation:'create', path:'src/new.js', content:'created' }
  ], snap);
  assert.equal(result.applied, true);
  assert.equal(await fs.readFile(path.join(root,'src/a.js'),'utf8'), 'new');
  assert.equal(await fs.readFile(path.join(root,'src/new.js'),'utf8'), 'created');
});

test('rejects traversal paths', async () => {
  const result = detectConflicts([{ operation:'update', path:'../escape.js', content:'x' }], {});
  assert.equal(result.clean, true);
  assert.deepEqual(result.conflicts, []);
});
