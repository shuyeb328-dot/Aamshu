import test from "node:test";
import assert from "node:assert/strict";
import { languageCatalog, isoCatalog, findLanguage, languageData } from "../src/services/languages.js";

test("language dataset has expected scale and unique IDs", () => {
  assert.equal(languageData.schemaVersion, 2);
  assert.ok(languageData.languageCount >= 300);
  assert.ok(languageData.localeCount >= 1000);
  assert.ok(languageData.iso639_3Count >= 7000);
  assert.equal(new Set(languageData.languages.map(x => x.id)).size, languageData.languages.length);
  assert.equal(new Set(languageData.locales.map(x => x.id)).size, languageData.locales.length);
  assert.equal(new Set(languageData.iso639_3.map(x => x.id)).size, languageData.iso639_3.length);
});

for (const id of ["en", "hi", "kn", "ta", "te", "ml", "ar", "ja", "es"]) {
  test(`finds ${id}`, () => assert.ok(findLanguage(id)));
}

test("catalog search and pagination are bounded", () => {
  const result = languageCatalog({ q: "kannada", limit: 10, offset: 0 });
  assert.equal(result.total >= 1, true);
  assert.ok(result.languages.length <= 10);
  const iso = isoCatalog({ q: "kannada", limit: 10, offset: 0 });
  assert.equal(iso.total >= 1, true);
});
