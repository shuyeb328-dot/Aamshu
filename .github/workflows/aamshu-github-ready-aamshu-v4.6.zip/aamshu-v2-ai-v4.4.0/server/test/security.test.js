import test from 'node:test';
import assert from 'node:assert/strict';
import { requestId } from '../src/services/security.js';
import { validateProviderUrl } from '../src/services/providerSecurity.js';

test('request ids are generated and stable for valid incoming ids', () => {
  const req = { headers: {} }; let next = false;
  requestId(req, {}, () => { next = true; });
  assert.equal(next, true); assert.match(req.requestId, /^[0-9a-f-]{36}$/);
});

test('provider URL rejects private address', async () => {
  await assert.rejects(() => validateProviderUrl('https://127.0.0.1:8443'), /private_address_blocked/);
});

test('provider URL rejects embedded credentials', async () => {
  await assert.rejects(() => validateProviderUrl('https://user:pass@example.com'), /credentials_in_url/);
});
