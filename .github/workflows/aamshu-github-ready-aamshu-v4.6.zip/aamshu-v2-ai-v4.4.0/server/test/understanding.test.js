import test from "node:test";
import assert from "node:assert/strict";
import {understand} from "../src/services/understanding.js";
import {companionReply} from "../src/services/companion.js";

test("understands troubleshooting intent",()=>assert.equal(understand("Why is my app crashing?").intent,"troubleshooting"));
test("detects supportive tone without diagnosing",()=>assert.equal(understand("I feel overwhelmed and frustrated").tone,"frustrated"));
test("uses recent human context",()=>assert.equal(understand("The bug is back",[{role:"human",text:"My app crashes after login"}]).contextTurns,1));
test("de-escalates violent language",async()=>assert.match((await companionReply("I want to fight him","assertive")).reply,/violence/i));
test("returns actionable style for build requests",()=>assert.equal(understand("Build a login screen").responseStyle,"direct_and_actionable"));
