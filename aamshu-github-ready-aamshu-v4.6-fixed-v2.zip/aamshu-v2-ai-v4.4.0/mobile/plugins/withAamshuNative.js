const { withAndroidManifest, withDangerousMod } = require('@expo/config-plugins');
const fs = require('fs');
const path = require('path');

function copyNative(projectRoot) {
  const src = path.join(projectRoot, 'native/android/com/aamshu/assistant');
  const dst = path.join(projectRoot, 'android/app/src/main/java/com/aamshu/assistant');

  if (!fs.existsSync(src)) {
    throw new Error(`Aamshu native source directory not found: ${src}`);
  }

  fs.mkdirSync(dst, { recursive: true });

  for (const file of fs.readdirSync(src)) {
    fs.copyFileSync(path.join(src, file), path.join(dst, file));
  }
}

function patchMainApplication(projectRoot) {
  const mainJava = path.join(
    projectRoot,
    'android/app/src/main/java/com/aamshu/mobile/MainApplication.java'
  );
  const mainKotlin = path.join(
    projectRoot,
    'android/app/src/main/java/com/aamshu/mobile/MainApplication.kt'
  );

  const candidates = [mainJava, mainKotlin];

  // Expo may place MainApplication under a slightly different package path.
  // Fall back to searching the generated Android source tree.
  let mainApplication = candidates.find(fs.existsSync);

  if (!mainApplication) {
    const srcRoot = path.join(projectRoot, 'android/app/src/main');
    if (fs.existsSync(srcRoot)) {
      const stack = [srcRoot];
      while (stack.length) {
        const dir = stack.pop();
        for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
          const full = path.join(dir, entry.name);
          if (entry.isDirectory()) stack.push(full);
          else if (entry.name === 'MainApplication.java' || entry.name === 'MainApplication.kt') {
            mainApplication = full;
            break;
          }
        }
        if (mainApplication) break;
      }
    }
  }

  if (!mainApplication) {
    throw new Error('Aamshu native plugin could not locate generated MainApplication.java or MainApplication.kt.');
  }

  let contents = fs.readFileSync(mainApplication, 'utf8');
  const pkg = 'com.aamshu.assistant.AamshuAssistantPackage';

  if (!contents.includes(pkg)) {
    if (mainApplication.endsWith('.java')) {
      contents = contents.replace(
        /^(package .*?;\n|package .*?\n)/m,
        '$1\nimport com.aamshu.assistant.AamshuAssistantPackage;\n'
      );

      if (contents.includes('PackageList(this).getPackages()')) {
        contents = contents.replace(
          /(List<ReactPackage> packages = new PackageList\(this\)\.getPackages\(\);)/,
          '$1\n          packages.add(new AamshuAssistantPackage());'
        );
      } else {
        throw new Error('Aamshu native plugin could not locate the React Native PackageList in MainApplication.java.');
      }
    } else {
      contents = contents.replace(
        /^(package .*?\n)/m,
        '$1\nimport com.aamshu.assistant.AamshuAssistantPackage\n'
      );

      if (contents.includes('PackageList(this).packages.apply {')) {
        contents = contents.replace(
          /(PackageList\(this\)\.packages\.apply \{)/,
          '$1\n              add(AamshuAssistantPackage())'
        );
      } else if (contents.includes('PackageList(this).packages')) {
        contents = contents.replace(
          /(PackageList\(this\)\.packages)/,
          '$1.apply {\n              add(AamshuAssistantPackage())\n          }'
        );
      } else {
        throw new Error('Aamshu native plugin could not locate the React Native PackageList in MainApplication.kt.');
      }
    }

    fs.writeFileSync(mainApplication, contents);
  }

  console.log(`Aamshu native package installed in ${mainApplication}`);
}

module.exports = function withAamshuNative(config) {
  config = withAndroidManifest(config, config => {
    const app = config.modResults.manifest.application?.[0];

    if (app) {
      app.service = app.service || [];
      app.receiver = app.receiver || [];

      if (!app.receiver.some(x => x.$?.['android:name'] === '.assistant.AamshuAssistantReceiver')) {
        app.receiver.push({
          $: {
            'android:name': '.assistant.AamshuAssistantReceiver',
            'android:exported': 'false'
          }
        });
      }

      if (!app.service.some(x => x.$?.['android:name'] === '.assistant.AamshuAssistantService')) {
        app.service.push({
          $: {
            'android:name': '.assistant.AamshuAssistantService',
            'android:exported': 'false',
            'android:foregroundServiceType': 'microphone',
            'android:stopWithTask': 'true'
          }
        });
      }
    }

    return config;
  });

  config = withDangerousMod(config, [
    'android',
    async config => {
      copyNative(config.modRequest.projectRoot);
      patchMainApplication(config.modRequest.projectRoot);
      return config;
    }
  ]);

  return config;
};
